﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace HashTableNS
{
    public class HashTable
    {
        public Node[] Table;

        public HashTable(int size =101)
        {
            Table = new Node[101];
            InitializeTable();
            PopulateTable();
        }
        private HashTable(Node[] N)
        {
            Table = N;
        }
        public void InitializeTable()
        {
            for(int c = 0; c < Table.Length; c++)
            {
                Table[c] = new Node();
            }
            Console.WriteLine(Table.Length);

        }
        public void PopulateTable()
        {
            int hloc = 0;
            int count;

            using (StreamReader sr = File.OpenText("../../../kwcsharp.txt"))
            {
                string input = null;
                bool atest = false;

                while((input = sr.ReadLine()) != null)
                {
                    count = 0;

                    Console.WriteLine(input);

                    while(!atest)
                    {
                        hloc = Hash(input) + count;
                        if(Table[hloc].Hash != -1)
                        {
                            count++;
                        }
                        else
                        {
                            atest = true;
                        }
                    }
                    Table[hloc].Key = input;
                    Table[hloc].Hash = hloc;
                }
            }
        }
        public int Hash(string bite)
        {
            int hash = 0;
            byte[] bytes = Encoding.ASCII.GetBytes(bite);

            foreach (byte b in bytes)
            {
                hash += b;
            }
            hash = (hash << 8) % 101;
            return hash;
        }
        public void Search(string file)
        {
            int pos = Hash(file);
            while(Table[pos].Key != file && Table[pos].Hash != -1)
            {
                if(pos + 5 >= Table.Length)
                {
                    pos = 5 - (Table.Length - pos);
                }
                else
                {
                    pos += 5;
                }
            }

        }
    }
}
