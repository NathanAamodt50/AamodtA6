﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashTableNS
{
    public class Node
    {
        public string Key { get; set; }
        public int Hash { get; set; }
        public int Probe { get; set; }
        public int Match { get; set; }
        public Node(string K = "", int H = -1,int P = 0, int M = 0)
        {
            Key = K;
            Hash = H;
            Probe = P;
            Match = M;
        }
        public Node( Node Soul)
        {
            Key = Soul.Key;
            Hash = Soul.Hash;
            Probe = Soul.Probe;
            Match = Soul.Match;
        }
    }
}
