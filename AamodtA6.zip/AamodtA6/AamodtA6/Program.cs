﻿using System;
using System.IO;
using static System.Console;

namespace HashTableNS
{

    class Program
    {
        static void Main(string[] args)
        {
            string filenameSearch = null, oneWord = null; ;
            int tableSize;
            Clear();
            if (args.Length != 2)
            {
                Write("Enter search file name: ");
                    filenameSearch = ReadLine();
                Write("Enter the hash table size: ");
                tableSize = Int32.Parse(ReadLine());
            }
            else
            {
                filenameSearch = args[0];
                tableSize = Int32.Parse(args[1]);
            }
            Clear();
            filenameSearch = "../../../" + filenameSearch;
            HashTable hashTable = new HashTable(tableSize);
            using(StreamReader sr = File.OpenText(filenameSearch))
            {
                while((oneWord = sr.ReadLine()) != null)
                {
                    hashTable.Search(oneWord);
                }
                View.ViewHT(hashTable);
            }
        }
    }
}
