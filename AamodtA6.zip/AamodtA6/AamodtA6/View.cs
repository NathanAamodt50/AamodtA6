﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashTableNS
{ 
    public static class View
    { 
     public static void ViewHT(HashTable hashTable)
        {
            Console.WriteLine("Stored        Hashed        Keyword        Probes        Matched");
            for (int i = 0; i < hashTable.Table.Length; i++)
            {

                Console.WriteLine(i + " \t\t  " + hashTable.Table[i].Hash + "  \t   " + hashTable.Table[i].Key+ "  \t\t    "+ hashTable.Table[i].Probe+"   \t\t  "+hashTable.Table[i].Match);
            }

            return;

        }
    
    }
}
